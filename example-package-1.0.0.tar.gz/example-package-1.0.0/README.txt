Example Package
===============

This is a sample package for demonstrating dist-git RPM generation.

The package is minimal and installs only this README file.
